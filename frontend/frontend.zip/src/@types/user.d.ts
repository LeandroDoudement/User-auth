interface User {
  id: number;
  email: string;
  fullname: string;
  age: string;
  phone: string;
  gender: string;
  password?: string;
  termsOfService: boolean;
}
