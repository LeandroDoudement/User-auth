interface ReadOnlyRowProps {
  user: User;
  deleteUser: Function;
  handleEditClick: Function;
}

const ReadOnlyRow = ({
  user,
  deleteUser,
  handleEditClick,
}: ReadOnlyRowProps) => {
  return (
    <tr key={user.id}>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <div className='flex items-center'>
          <div className='ml-3'>
            <p className='text-gray-900 whitespace-no-wrap'>{user.fullname}</p>
          </div>
        </div>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <p className='text-gray-900 whitespace-no-wrap'>{user.age}</p>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <p className='text-gray-900 whitespace-no-wrap'>{user.phone}</p>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <p className='text-gray-900 whitespace-no-wrap'>{user.gender}</p>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <p className='text-gray-900 whitespace-no-wrap'>{user.email}</p>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm'>
        <p className='text-gray-900 whitespace-no-wrap'>
          {user.termsOfService ? 'Accepted' : 'Not Accepted'}
        </p>
      </td>
      <td className='px-5 py-5 border-b border-gray-200 bg-white text-sm flex gap-4'>
        <button
          className='text-blue-500'
          onClick={(event) => handleEditClick(event, user)}
        >
          Editar
        </button>
        <button
          className='text-red-500 ml-2'
          onClick={() => deleteUser(user.id)}
        >
          X
        </button>
      </td>
    </tr>
  );
};

export default ReadOnlyRow;
